/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback, useMemo } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Sparkles, 
  Download, 
  RefreshCcw, 
  X, 
  Maximize2, 
  Layers,
  ArrowRight,
  Loader2,
  Trash2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';

// --- Constants ---
const VIBE_SEEDS = [
  "minimalist rainy cyberpunk with neon highlights",
  "pastel dreamy clouds at golden hour, studio ghibli style",
  "dark forest with bioluminescent fireflies and ancient ruins",
  "abstract geometric liquid chrome in deep violet",
  "vintage 70s desert sunset with grainy film texture",
  "ethereal underwater garden with glowing jellyfish",
  "brutalist architecture in a snowy mountain range, overcast",
  "lo-fi study room with city rain outside the window",
  "surreal marble statues floating in a nebula",
  "minimalist line art of Mediterranean waves",
  "noir detective office with heavy shadows and cigarette smoke",
  "retro-futurist space station viewing earth",
];

// --- Types ---
interface Generation {
  id: string;
  prompt: string;
  images: string[]; // base64 strings
  timestamp: number;
}

// --- App ---
export default function App() {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generations, setGenerations] = useState<Generation[]>([]);
  const [selectedImage, setSelectedImage] = useState<{ src: string, prompt: string } | null>(null);
  const [remixImage, setRemixImage] = useState<string | null>(null);

  const ai = useMemo(() => new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! }), []);

  const generateWallpapers = async () => {
    if (!prompt.trim() || isGenerating) return;

    setIsGenerating(true);
    const currentPrompt = prompt;
    const currentRemix = remixImage;

    try {
      // We want 4 variations. Parallelize 4 calls.
      const generationTasks = Array.from({ length: 4 }).map(async () => {
        const contents: any[] = [];
        
        if (currentRemix) {
          contents.push({
            inlineData: {
              data: currentRemix.split(',')[1], // Remove "data:image/png;base64,"
              mimeType: "image/png"
            }
          });
          contents.push({ text: `Create a variation of this image with the following vibe: ${currentPrompt}. Maintain the style and composition but adapt it to the new description.` });
        } else {
          contents.push({ text: `Create a stunning phone wallpaper with the following vibe: ${currentPrompt}. High quality, detailed, optimized for 9:16 aspect ratio.` });
        }

        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: { parts: contents },
          config: {
            imageConfig: {
              aspectRatio: "9:16",
            },
          },
        });

        // Find the image part
        const imagePart = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
        if (imagePart?.inlineData?.data) {
          return `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`;
        }
        throw new Error('No image generated in one of the variations');
      });

      const results = await Promise.allSettled(generationTasks);
      const successfulImages = results
        .filter((r): r is PromiseFulfilledResult<string> => r.status === 'fulfilled')
        .map(r => r.value);

      if (successfulImages.length > 0) {
        const newGen: Generation = {
          id: crypto.randomUUID(),
          prompt: currentPrompt,
          images: successfulImages,
          timestamp: Date.now(),
        };
        setGenerations(prev => [newGen, ...prev]);
        setRemixImage(null); // Clear remix after successful generation
      }
    } catch (error) {
      console.error('Generation failed:', error);
      alert('Failed to generate wallpapers. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const downloadImage = (src: string, filename: string) => {
    const link = document.createElement('a');
    link.href = src;
    link.download = `${filename}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleRemix = (src: string, prompt: string) => {
    setRemixImage(src);
    setPrompt(prompt);
    setSelectedImage(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#E5E5E5] font-sans selection:bg-indigo-500/30">
      {/* Background Atmosphere */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-20%] left-[-10%] w-[100%] h-[60%] bg-indigo-900/10 blur-[160px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[40%] bg-indigo-600/5 blur-[120px] rounded-full" />
      </div>

      <div className="relative z-10 max-w-2xl mx-auto px-6 py-12 flex flex-col min-h-screen">
        {/* Header */}
        <header className="mb-16 text-center">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1 glass rounded-full mb-6"
          >
            <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse" />
            <span className="text-[10px] uppercase tracking-[0.3em] font-semibold text-zinc-500">Aura Engine 2.0</span>
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-7xl vibe-text tracking-tighter text-indigo-400 mb-2"
          >
            Studio.
          </motion.h1>
          <p className="text-zinc-500 text-[11px] uppercase tracking-[0.2em] font-medium">
            Curate your digital atmosphere
          </p>
        </header>

        {/* Input Area */}
        <div className="mb-20">
          <label className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-semibold mb-3 block px-1">Current Mood</label>
          <div className="relative group">
            <div className="absolute -inset-0.5 bg-indigo-500/20 rounded-2xl blur opacity-0 group-focus-within:opacity-100 transition duration-1000"></div>
            <div className="relative glass rounded-2xl p-6">
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="The feeling of neon drizzle on chrome..."
                className="w-full bg-transparent border-none focus:ring-0 text-xl vibe-text text-white placeholder:text-zinc-700 resize-none min-h-[100px] outline-none leading-relaxed"
              />
              
              <div className="flex items-center justify-between mt-6 pt-6 border-t border-white/5">
                <div className="flex items-center gap-3">
                  {remixImage && (
                    <motion.div 
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="relative group/remix"
                    >
                      <img 
                        src={remixImage} 
                        className="w-10 h-16 object-cover rounded border border-indigo-500/30 glow-indigo"
                        alt="Remix reference"
                      />
                      <button 
                        onClick={() => setRemixImage(null)}
                        className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-0.5"
                      >
                        <X className="w-2.5 h-2.5" />
                      </button>
                    </motion.div>
                  )}
                  <button
                    onClick={() => {
                      const randomVibe = VIBE_SEEDS[Math.floor(Math.random() * VIBE_SEEDS.length)];
                      setPrompt(randomVibe);
                    }}
                    className="flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/5 rounded-full text-[10px] uppercase tracking-widest text-zinc-500 transition-colors"
                  >
                    <RefreshCcw className="w-3 h-3" />
                    IDK
                  </button>
                  <div className="hidden sm:block">
                    <span className="text-[10px] uppercase tracking-widest text-zinc-800">Visual Aura</span>
                  </div>
                </div>

                <button
                  onClick={generateWallpapers}
                  disabled={!prompt.trim() || isGenerating}
                  className={cn(
                    "flex items-center gap-2 px-8 py-3.5 rounded font-semibold text-[11px] uppercase tracking-[0.2em] transition-all",
                    isGenerating 
                      ? "bg-white/5 text-zinc-600 cursor-not-allowed" 
                      : "bg-white text-black hover:bg-indigo-400 active:scale-95"
                  )}
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Processing
                    </>
                  ) : (
                    <>
                      Generate
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Loading Skeleton */}
        {isGenerating && (
          <div className="mb-16">
            <div className="grid grid-cols-2 gap-4">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="aspect-[9/16] glass rounded-xl animate-pulse flex items-center justify-center border-indigo-500/10">
                  <div className="w-12 h-0.5 bg-indigo-500/10" />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* History / Generations */}
        <div className="space-y-20">
          {generations.map((gen, idx) => (
            <section key={gen.id} className="relative">
              <div className="flex items-end justify-between mb-8 pb-4 border-b border-white/5">
                <div>
                  <h2 className="text-zinc-500 text-[10px] uppercase tracking-[0.3em] font-semibold mb-2">
                    {idx === 0 ? 'Latest Batch' : 'Archive'}
                  </h2>
                  <p className="text-2xl vibe-text text-white leading-none">{gen.prompt}</p>
                </div>
                <button 
                  onClick={() => setGenerations(prev => prev.filter(g => g.id !== gen.id))}
                  className="p-2 text-zinc-700 hover:text-red-400 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {gen.images.map((img, i) => (
                  <motion.div
                    key={i}
                    whileHover={{ y: -8 }}
                    className="relative aspect-[9/16] rounded-xl overflow-hidden cursor-zoom-in border border-white/5 glass group"
                    onClick={() => setSelectedImage({ src: img, prompt: gen.prompt })}
                  >
                    <img 
                      src={img} 
                      alt={`Variation ${i + 1}`} 
                      className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-all duration-500"
                      referrerPolicy="no-referrer"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-6">
                      <p className="text-[10px] uppercase tracking-widest mb-1 text-indigo-400 font-bold">Variation {i + 1}</p>
                      <p className="text-xs vibe-text text-zinc-300 line-clamp-1">{gen.prompt}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </section>
          ))}
          
          {generations.length === 0 && !isGenerating && (
            <div className="py-24 text-center glass rounded-3xl border-dashed">
              <div className="w-16 h-16 glass rounded-full flex items-center justify-center mx-auto mb-6">
                <Sparkles className="w-6 h-6 text-indigo-400" />
              </div>
              <p className="text-zinc-500 vibe-text text-xl">The atelier is silent.<br/>Invoke a mood to begin.</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <footer className="mt-auto pt-24 pb-12 flex items-center justify-between border-t border-white/5">
          <span className="text-[9px] text-zinc-700 uppercase tracking-[0.4em] font-semibold">Aura.Editorial</span>
          <span className="text-[9px] text-zinc-800 uppercase tracking-widest font-mono">© 2026 AI Studio</span>
        </footer>
      </div>

      {/* Full Screen Modal */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex flex-col sm:flex-row bg-[#050505] p-6 lg:p-12 overflow-hidden"
          >
            {/* Sidebar Desktop/Top Mobile */}
            <div className="flex flex-col w-full sm:w-80 h-auto sm:h-full justify-between mb-8 sm:mb-0 sm:mr-12">
              <div className="space-y-8 lg:space-y-12">
                <div className="flex items-center justify-between">
                  <h1 className="text-4xl vibe-text tracking-tighter text-indigo-400">Preview.</h1>
                  <button 
                    onClick={() => setSelectedImage(null)}
                    className="p-3 glass rounded-full hover:bg-white/10 transition-colors"
                  >
                    <X className="w-5 h-5 text-white" />
                  </button>
                </div>

                <div className="space-y-6">
                  <div>
                    <label className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-semibold mb-3 block">Selected Tone</label>
                    <div className="glass p-5 rounded-lg border-indigo-500/20">
                      <p className="text-xl vibe-text text-white leading-tight">{selectedImage.prompt}</p>
                    </div>
                  </div>
                  
                  <div className="hidden lg:block">
                    <label className="text-[10px] uppercase tracking-[0.2em] text-zinc-500 font-semibold mb-3 block">Metadata</label>
                    <div className="space-y-4">
                      <div className="flex justify-between text-[11px] font-medium tracking-wider">
                        <span className="text-zinc-500">Dimensions</span>
                        <span className="text-white">1080 x 1920</span>
                      </div>
                      <div className="h-[1px] bg-zinc-900 w-full" />
                      <div className="flex justify-between text-[11px] font-medium tracking-wider">
                        <span className="text-zinc-500">Format</span>
                        <span className="text-white">PNG / 4K Alpha</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4 pt-12 sm:pt-0">
                <button
                  onClick={() => downloadImage(selectedImage.src, `aura-${Date.now()}`)}
                  className="w-full py-4 bg-white text-black font-semibold text-[11px] uppercase tracking-widest rounded hover:bg-indigo-400 transition-all active:scale-95"
                >
                  Download Asset
                </button>
                <button
                  onClick={() => handleRemix(selectedImage.src, selectedImage.prompt)}
                  className="w-full py-4 glass text-white font-semibold text-[11px] uppercase tracking-widest rounded-full hover:bg-white/10 transition-all flex items-center justify-center gap-2"
                >
                  <RefreshCcw className="w-3.5 h-3.5" />
                  Remix Signature
                </button>
              </div>
            </div>

            {/* Main Content: The Device Preview */}
            <div className="flex-1 flex items-center justify-center relative">
              <div className="absolute hidden lg:block -left-12 top-1/2 -translate-y-1/2 text-[10px] text-zinc-800 uppercase tracking-[0.6em] whitespace-nowrap rotate-180" style={{ writingMode: 'vertical-rl' }}>
                Device Visualization Mode
              </div>

              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="relative aspect-[9/16] w-full max-w-[320px] lg:max-w-[380px] rounded-[3.5rem] overflow-hidden border-[8px] border-zinc-900 shadow-[0_40px_100px_rgba(0,0,0,0.8)] ring-1 ring-white/10"
              >
                <img 
                  src={selectedImage.src} 
                  className="w-full h-full object-cover" 
                  alt="Full view"
                  referrerPolicy="no-referrer"
                />
                
                {/* Minimal Interface Overlays */}
                <div className="absolute top-12 left-0 w-full text-center">
                  <p className="text-6xl font-light text-white tracking-tighter drop-shadow-2xl">12:48</p>
                  <p className="text-[10px] uppercase tracking-[0.4em] text-white/60 mt-2 font-semibold">Monday, October 23</p>
                </div>

                {/* Device Indicators */}
                <div className="absolute top-5 left-1/2 -translate-x-1/2 w-24 h-7 bg-black rounded-3xl" />
                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-32 h-1 bg-white/20 rounded-full" />
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
